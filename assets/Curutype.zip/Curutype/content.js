var txt = document.getElementsByTagName("h1");
var txt2 = document.getElementsByTagName("h2");
var txt3 = document.getElementsByTagName("h3");


console.log(txt);
console.log(txt2);

for (var i = 0; i < txt.length; i++) {
    console.log("Coisou");
    txt[i].style.fontFamily = "Curutype";
    txt[i].style.fontWeight = "normal";
}
for (var i = 0; i < txt2.length; i++) {
    console.log("Coisou");
    txt2[i].style.fontFamily = "Curutype";
    txt2[i].style.fontWeight = "normal";
}
for (var i = 0; i < txt3.length; i++) {
    console.log("Coisou");
    txt3[i].style.fontFamily = "Curutype";
    txt3[i].style.fontWeight = "normal";
}

var newStyle = document.createElement('style');
newStyle.appendChild(document.createTextNode("\
    @font-face {\
        font-family: " + "Curutype" + ";\
        src: url('" + "./Curutype.otf" + "') format('otf');\
    }\
    h1, h2, h3{\
        font-weight: normal;\
    }\
    "));

document.head.appendChild(newStyle);

